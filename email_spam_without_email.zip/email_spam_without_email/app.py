from flask import Flask, render_template, request
import pickle


# ---------------------------------------
# Create Flask Application
# ---------------------------------------

app = Flask(__name__)


# ---------------------------------------
# Load Trained Model
# ---------------------------------------

with open("model/spam_model.pkl", "rb") as file:
    model = pickle.load(file)


# ---------------------------------------
# Load TF-IDF Vectorizer
# ---------------------------------------

with open("model/vectorizer.pkl", "rb") as file:
    vectorizer = pickle.load(file)


# ---------------------------------------
# Home Page
# ---------------------------------------

@app.route("/")
def home():
    return render_template(
        "index.html",
        prediction=None,
        probability=None,
        message=""
    )


# ---------------------------------------
# Spam Prediction
# ---------------------------------------

@app.route("/predict", methods=["POST"])
def predict():

    message = request.form.get("message", "").strip()

    if not message:

        return render_template(
            "index.html",
            prediction="Please enter an email message.",
            probability=None,
            message=""
        )

    # Convert text into TF-IDF features
    message_vectorized = vectorizer.transform([message])

    # Make prediction
    prediction = model.predict(message_vectorized)[0]

    # Get probability
    probabilities = model.predict_proba(message_vectorized)[0]

    spam_probability = probabilities[1] * 100

    ham_probability = probabilities[0] * 100


    # ---------------------------------------
    # Result
    # ---------------------------------------

    if prediction == 1:

        result = "SPAM EMAIL"

        probability = round(spam_probability, 2)

    else:

        result = "NOT SPAM"

        probability = round(ham_probability, 2)


    return render_template(
        "index.html",
        prediction=result,
        probability=probability,
        message=message
    )


# ---------------------------------------
# Run Application
# ---------------------------------------

if __name__ == "__main__":
    app.run(debug=True)